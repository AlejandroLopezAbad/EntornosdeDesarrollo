package entity;


public class Tienda {
	private final static int NUM_PRODUCTOS = 20;
	private Producto[] productos;
	private double[] margenBeneficio;
	private double[] preciosActualizados;
	private double beneficio;
	private double maxMargen;
	private int productoMaxMargen;
	private double minMargen;
	private int productoMinMargen;
/**
 * constructor por defecto de tienda con unos valores cargados
 */
	public Tienda() {
		productos = new Producto[NUM_PRODUCTOS];
		margenBeneficio = new double[NUM_PRODUCTOS];
		beneficio = 0;
		maxMargen = 0;
		productoMaxMargen = 0;
		minMargen = 0;
		productoMinMargen = 0;
		preciosActualizados = new double[NUM_PRODUCTOS];
	}
	/**
	 * Getter del array  producto
	 * 
	 * @return idproducto
	 */

	public Producto[] getProductos() {
		return productos;
	}
/**
 * Setter que carga un un valor Producto[] 
 * @param productos
 */
	public void setProductos(Producto[] productos) {
		this.productos = productos;
	}
	/**
	 * Getter de la variable beneficio
	 * 
	 * @return beneficio
	 */

	public double getBeneficio() {
		return beneficio;
	}
	/**
	 * Setter que carga un valor double a la variable beneficio
	 * @param beneficio
	 */
	

	public void setBeneficio(double beneficio) {
		this.beneficio = beneficio;
	}
/**
 * Getter de un Int que es constante
 * @return NUM_PRODUCTOS
 */
	public static int getNumProductos() {
		return NUM_PRODUCTOS;
	}
/**
 * Getter de un double[] de margen de beneficio
 * @return margenBeneficio
 */
	public double[] getMargenBeneficio() {
		return margenBeneficio;
	}

	/**
	 * Setter que carga un valor double[] en margenBeneficio
	 * @param margenBeneficio
	 */
	public void setMargenBeneficio(double[] margenBeneficio) {
		this.margenBeneficio = margenBeneficio;
	}
/**
 * Getter de un double[] de precios actualizados
 * @return preciosActualizados
 */
	public double[] getPreciosActualizados() {
		return preciosActualizados;
	}
	/**
	 * Setter que carga un double[] a precios actualizados
	 * @param preciosActualizados
	 */
	public void setPreciosActualizados(double[] preciosActualizados) {
		this.preciosActualizados = preciosActualizados;
	}

	/**
	 * Getter de un maxMargen que es un double
	 * @return
	 */
	public double getMaxMargen() {
		return maxMargen;
	}
/**
 * Setter que carga un valor double a productoMaxMargen
 * @param productoMaxMargen
 */
	public void setMaxMargen(double productoMaxMargen) {
		this.maxMargen = productoMaxMargen;
	}
/**
 * Getter de un minMargen que es un double
 * @return
 */
	public double getMinMargen() {
		return minMargen;
	}
/**
 * Setter que carga un valor double a productoMinMargen
 * @param productoMinMargen
 */
	public void setMinMargen(double productoMinMargen) {
		this.minMargen = productoMinMargen;
	}
/**
 * Getter de un ProductomaxMargen que es un int-
 * @return productoMaxMargen
 */
	public int getProductoMaxMargen() {
		return productoMaxMargen;
	}
/**
 * Setter que carga un valor int a productoMaxMargen
 * @param productoMaxMargen
 */
	public void setProductoMaxMargen(int productoMaxMargen) {
		this.productoMaxMargen = productoMaxMargen;
	}
/**
 * Getter de un ProductoMinMargen que es un int
 * @return productoMinMargen
 */
	public int getProductoMinMargen() {
		return productoMinMargen;
	}
/**
 * Setter que carga un int en productoMinMargen
 * @param productoMinMargen
 */
	public void setProductoMinMargen(int productoMinMargen) {
		this.productoMinMargen = productoMinMargen;
	}

}
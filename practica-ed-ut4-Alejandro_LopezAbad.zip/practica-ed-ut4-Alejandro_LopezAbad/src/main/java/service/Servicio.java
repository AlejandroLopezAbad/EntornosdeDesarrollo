package service;

import java.math.BigDecimal;
import java.math.RoundingMode;

import entity.Producto;
import entity.Tienda;
import simulador.*;

public class Servicio {

	Randoms random = new Randoms();
	Tienda tienda = new Tienda();

	
	public Servicio() {

	}
/**
 * Es un m�todo donde cargamos el margen de beneficio y lo retornamos para conseguir un valor que tiene como parametro de entrada un objeto tienda
 * @param tienda
 * @return arrayMargenes
 */
	// Operaciones
	// 1. Calcula Margen de beneficio

	public double[] margenBeneficio(Tienda tienda) {

		double[] arrayMargenes = new double[tienda.getProductos().length];

		for (int i = 0; i < tienda.getProductos().length; i++) {
			arrayMargenes[i] = BigDecimal
					.valueOf(((tienda.getProductos()[i].getPrecio() - tienda.getProductos()[i].getCoste())
							/ tienda.getProductos()[i].getPrecio()) * 100)
					.setScale(2, RoundingMode.HALF_UP).doubleValue();
		}
		tienda.setMargenBeneficio(arrayMargenes);
		return arrayMargenes;
	}

	/**
	 * Metodo que calcula el mayor margen de beneficio de la tienda que tiene como parametro de entrada un objeto tienda
	 * @param tienda
	 */
	//2.
	public void mayorMargenBeneficio(Tienda tienda) {
        // double postEval = Double.MIN_VALUE;
        double aux = 0;
        for (int i = 0; i < tienda.getMargenBeneficio().length; i++) {
            double margenMayorTemporal = tienda.getMargenBeneficio()[i];
            if (margenMayorTemporal > aux) {
                aux = margenMayorTemporal;
                tienda.setMaxMargen(margenMayorTemporal);
                tienda.setProductoMaxMargen(i + 1);
            }
        }
    }
/**
 * Metodo que calcula el menor margen de beneficio de una tienda que tiene como parametro de entrada un objeto tienda
 * @param tienda
 */
    // 3. Obtener el id del producto con menor margen de beneficio
    public void menorMargenBeneficio(Tienda tienda) {
        double aux = 100000;
        // double postEval = Double.MAX_VALUE;

        for (int i = 0; i < tienda.getMargenBeneficio().length; i++) {
            double margenMenorTemporal = tienda.getMargenBeneficio()[i];
            if (margenMenorTemporal < aux) {
                aux = margenMenorTemporal;
                tienda.setMinMargen(margenMenorTemporal);
                tienda.setProductoMinMargen(i + 1);
            }
        }
    }
/**
 * metodo que calcula el nuevo precio de un producto si su margen es de almenos 10% que tiene como parametro de entrada un objeto tienda
 * @param tienda
 * @return arrayNuevoPrecio
 */
	// 4. Calcular el precio del producto para todos aquellos productos que no
	// tengan al menos un margen del 10%
	public double[] nuevoPrecioMargenMenorDiez(Tienda tienda) {
		// declaro la variable para el 10% evitando magic numbers
		int porcentajeBeneficioPequenio = 10;
		double fraccionPorcentaje = 0.1;
		double[] arrayNuevoPrecio = new double[tienda.getProductos().length];
		for (int i = 0; i < tienda.getMargenBeneficio().length; i++) {
			if (tienda.getMargenBeneficio()[i] < porcentajeBeneficioPequenio) {
				arrayNuevoPrecio[i] = BigDecimal
						.valueOf((tienda.getProductos()[i].getCoste() / (1 - fraccionPorcentaje)))
						.setScale(2, RoundingMode.HALF_UP).doubleValue();
			}
		}
		tienda.setPreciosActualizados(arrayNuevoPrecio);
		return arrayNuevoPrecio;
	}

	/**
	 * Es un metodo que calcula el Beneficio total de la tienda, que tiene como parametro de entrada un objeto tienda
	 * @param tienda
	 * @return beneficios
	 */
	
	// 5. Beneficio total
	public double beneficioTotal(Tienda tienda) {
		double beneficio = tienda.getBeneficio();
		for (int i = 0; i < tienda.getProductos().length; i++) {
			beneficio = BigDecimal
					.valueOf(beneficio + (tienda.getProductos()[i].getPrecio() - tienda.getProductos()[i].getCoste()))
					.setScale(2, RoundingMode.HALF_UP).doubleValue();
		}
		tienda.setBeneficio(beneficio);
		return beneficio;
	}

	/**
	 * Es un metodo intermedio que hemos utilizado para poder imprimir preciosy tiene como parametro de entrada un objeto tienda
	 * 
	 * @param tienda
	 * @return precios
	 */

	public double[] creararraysPrecios(Tienda tienda) {
	
double[]precios= new double[tienda.getProductos().length];
	
for (int i = 0; i < tienda.getProductos().length; i++) {
	
	precios[i]=tienda.getProductos()[i].getPrecio(); 
}
	return precios;
}


/**
 * Es un meotodo intermedio que hemos utilizado para poder imprimir los costes y tiene como parametro de entrada un objeto tienda
 * @param tienda
 * @return costes
 */

	public double[] creararraysCostes(Tienda tienda) {
	
	double[]costes= new double[tienda.getProductos().length];
		
	for (int i = 0; i < tienda.getProductos().length; i++) {
		
		costes[i]=tienda.getProductos()[i].getCoste(); 
	}
	return costes;
	}





 
 
 }
 
	



package service;

import entity.Producto;
import entity.Tienda;
import simulador.Randoms;


public class GenerarTienda {
	
	Randoms random = new Randoms();

	/**
	 *  Es un m�todo que genera un array de productos, los cuales han sido obtenidos con la ayuda de otros metodos {@link Randoms} y se introduce como un producto a la tienda
	 * @return tienda
	 */
	
	public Tienda generaTienda() {
		
		Tienda tienda = new Tienda();
		
		Producto[] productos = new Producto[Tienda.getNumProductos()];
		
		for (int i = 0; i < productos.length; i++) {
			Producto producto = new Producto();
			producto.setPrecio(random.generadorPrecios()[i]);
			producto.setCoste(random.generadorCoste()[i]);
			productos[i] = producto;
		}
		tienda.setProductos(productos);
		return tienda;
	}
}
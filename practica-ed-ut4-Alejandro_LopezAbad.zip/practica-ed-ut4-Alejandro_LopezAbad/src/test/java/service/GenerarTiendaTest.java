package service;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class GenerarTiendaTest {

	GenerarTienda mercadonaTest= new GenerarTienda();
	/**
	 * Este Test sirve para confirmar que se genera una tienda
	 * 
	 */
	@Test
	public void generarTiendaOk() {
		
		Assertions.assertTrue(mercadonaTest.generaTienda().getProductos().length==20);
		
	}
	/**
	 * Este Test sirve para confirmar que se genera una tienda
	 * 
	 */
	@Test 
	public void generaTiendaOk() {
		Assertions.assertTrue(mercadonaTest.generaTienda()==null);
	}

	
	
	
	
	
	
}

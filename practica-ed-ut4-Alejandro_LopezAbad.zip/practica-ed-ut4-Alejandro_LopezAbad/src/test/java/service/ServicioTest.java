package service;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import entity.Producto;
import entity.Tienda;

public class ServicioTest {
	Servicio servTest=new Servicio();
	Tienda tiendaTest=new  Tienda();
	Producto prodTest1=new Producto(100,50);
	Producto prodTest2=new Producto(10,10);
	Producto prodTest3=new Producto(19,10);
	Producto[]productos = {prodTest1,prodTest2,prodTest3};
	
	
	/*
	 * Test para comprobar que la salida del margen de beneficios sea Ok
	 * 
	 */
	@Test
	
	public void margenBeneficioSalidaOK() {
		tiendaTest.setProductos(productos);
		Assertions.assertTrue(servTest.margenBeneficio(tiendaTest).length==productos.length);
									}
	/**
	 * Test para comprobar que el calculo de margen de beneficio este ok
	 * 
	 */
	
		@Test
    public void margenBeneficioCalculoOk() {
        tiendaTest.setProductos(productos);
        Assertions.assertEquals(50.0, servTest.margenBeneficio(tiendaTest)[0]);
    }
		/**
		 * Test para comprobar que el calculo del mayor margen de beneficio este ok
		 * 
		 */
	
	@Test
	public void mayorMargenBeneficioCalculoOk() {
		 tiendaTest.setProductos(productos);
		 servTest.margenBeneficio(tiendaTest);
		 servTest.mayorMargenBeneficio(tiendaTest);
	
		 Assertions.assertEquals(50.0,tiendaTest.getMaxMargen());
		/** 
		 * Test para comprobar que el calculo del menor margen de beneficio este ok
		 * 
		 */
	}
	@Test
	public void menorMargenBeneficioCalculoOk() {
		 tiendaTest.setProductos(productos);
		 servTest.margenBeneficio(tiendaTest);
		 servTest.menorMargenBeneficio(tiendaTest);
	
		 Assertions.assertEquals(0.0,tiendaTest.getMinMargen());		
	}
	/**
	 * Test para comprobar que el calculo del nuevo precio este ok
	 * 
	 */
	@Test
	public void nuevoPrecioCalculoOk() {
		tiendaTest.setProductos(productos);
		 servTest.margenBeneficio(tiendaTest);
		 servTest.nuevoPrecioMargenMenorDiez(tiendaTest);
		 Assertions.assertNotEquals(0.0,tiendaTest.getProductos()[2].getPrecio());
		
	}
	/**
	 * 
	 * Test para comprobar que el calculo total de beneficio este ok 
	 * 
	 */
	
	@Test
	public void beneficioTotalCalculoOK() {
		tiendaTest.setProductos(productos);
		
		Assertions.assertEquals(59.0,servTest.beneficioTotal(tiendaTest));
		
		
	}
	
	/**
	 * Test para comprobar que el length del array es igual al creado
	 * 
	 */
	@Test
	public void crearArrayPreciosOk() {
		
		tiendaTest.setProductos(productos);
		Assertions.assertTrue(servTest.creararraysPrecios(tiendaTest).length==productos.length);
		
		
	}
	/**
	 * Test para comprobar que el length del array es igual al creado
	 * 
	 
	 */
	@Test
	public void crearArrayCostesOk() {
		
		tiendaTest.setProductos(productos);
		Assertions.assertTrue(servTest.creararraysCostes(tiendaTest).length==productos.length);
		
		
	}
	
	
	

}

package simulador;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class RandomsTest {
	
	Randoms rand1 =new Randoms();
	
	
	/**
	 * Este Test sirve para comprobar que el generador de precios funciona ok
	 * 
	 */
	@Test
	public void generadorPreciosOK() {
		Assertions.assertTrue(rand1.generadorPrecios().length==20);
	}
	
	/**
	 * Este Test sirve para comprobar que el generador de precios funciona ok
	 * 
	 */
	@Test
	public void generadorPreciosNotNull() {
		Assertions.assertTrue(rand1.generadorPrecios()==null);
	}
	/**
	 * Este Test sirve para comprobar que el generador de costes funciona ok
	 * 
	 */
	@Test
	public void generadorCostesOK() {
		Assertions.assertTrue(rand1.generadorCoste().length==20);
	}
	/**
	 * Este Test sirve para comprobar que el generador de costes funciona ok
	 *
	 */
	@Test
	public void generadorCostesNotNull() {
		Assertions.assertTrue(rand1.generadorCoste()==null);
	}
	
	

}
